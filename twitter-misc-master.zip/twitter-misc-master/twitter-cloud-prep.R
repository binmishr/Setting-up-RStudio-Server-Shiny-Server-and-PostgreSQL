



# deployApp("twitter-cloud", appName = "twitter-test1")
# in a terminal:
# sudo cp -R twitter-monitor /srv/shiny-server/

# http://52.64.126.221/shiny/twitter-cloud/
